'use strict';
const defaultConfig={enabled:true,methods:{modifyPublishBody:true,privateFirst:false}};
let config=defaultConfig,requestLog=[];
const videoIdsByTab=new Map();
const initialized=chrome.storage.local.get(['config','publishLog']).then(stored=>{
 config={enabled:stored.config?.enabled!==false,methods:{modifyPublishBody:true,privateFirst:false}};
 requestLog=Array.isArray(stored.publishLog)?stored.publishLog.slice(-100):[];
 return chrome.storage.local.remove(['requestLog','sessions','sessionCounter']);
});
function extensionUI(sender){return ['popup/popup.html','options/options.html','upload/patcher.html'].some(p=>sender.url?.split('?')[0]===chrome.runtime.getURL(p));}
function siteSender(sender){try{return new URL(sender.url||sender.tab?.url).hostname.endsWith('.tiktok.com');}catch{return false;}}
function notify(message){chrome.runtime.sendMessage(message).catch(()=>{});}
async function selectedTab(sender){if(sender.tab?.id!=null)return sender.tab;return (await chrome.tabs.query({active:true,currentWindow:true}))[0];}
async function forward(message,sender){const tab=await selectedTab(sender);if(!tab?.id)return {watching:false,ok:false};return chrome.tabs.sendMessage(tab.id,message).catch(()=>({watching:false,ok:false}));}
async function broadcastConfig(){const tabs=await chrome.tabs.query({url:'https://*.tiktok.com/*'});for(const tab of tabs)chrome.tabs.sendMessage(tab.id,{type:'CONFIG_UPDATED',config}).catch(()=>{});notify({type:'CONFIG_UPDATED',config});}
chrome.action.onClicked.addListener(async tab=>{if(!tab?.id||!siteSender({url:tab.url})){await chrome.tabs.create({url:'https://www.tiktok.com/'});return;}chrome.tabs.sendMessage(tab.id,{type:'TOGGLE_PANEL'}).catch(()=>{});});
chrome.runtime.onInstalled.addListener(()=>chrome.action.setPopup({popup:''}));
const analysisCache = new Map();
const analysisInFlight = new Map();
function validateWatchingUrl(value) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || !/(^|\.)tiktok\.com$/.test(u.hostname) || !/\/video\/\d+/.test(u.pathname)) {
    throw new Error('Open a published TikTok video to analyze it.');
  }
  return u.origin + u.pathname;
}
async function analyzeTikwm(value) {
  const apiKey = '';
  const url = validateWatchingUrl(value);
  const cached = analysisCache.get(url);
  if (cached && Date.now()-cached.time < 120000) return cached.data;
  if (analysisInFlight.has(url)) return analysisInFlight.get(url);
  const job = (async () => {
    const endpoint = new URL('https://api.tikwmapi.com/');
    endpoint.searchParams.set('url',url);
    endpoint.searchParams.set('hd','1');
    const response = await fetch(endpoint.href, {
      headers: { 'x-tikwmapi-key': apiKey },
      credentials: 'omit', signal: AbortSignal.timeout(30000)
    });
    if (!response.ok) throw new Error('TikWM HTTP ' + response.status);
    const result = await response.json();
    if (result.code !== 0 || !result.data) throw new Error(String(result.msg || 'TikWM could not analyze this video.'));
    analysisCache.set(url,{time:Date.now(),data:result.data});
    if (analysisCache.size > 30) analysisCache.delete(analysisCache.keys().next().value);
    return result.data;
  })();
  analysisInFlight.set(url,job);
  try { return await job; } finally { analysisInFlight.delete(url); }
}
function isExtensionPanel(sender) {
  return sender.url?.startsWith(chrome.runtime.getURL('popup/popup.html'));
}


async function handle(msg,sender){
 await initialized;
 if(!extensionUI(sender)&&!siteSender(sender))throw new Error('Unsupported sender.');
 switch(msg.type){
 case 'GET_CONFIG':return {config};
 case 'SET_CONFIG':if(!isExtensionPanel(sender))throw new Error('Open the panel to change Method.');config={enabled:msg.config?.enabled!==false,methods:{modifyPublishBody:true,privateFirst:false}};await chrome.storage.local.set({config});await broadcastConfig();return {ok:true};
 case 'GET_VIDEO_STATS':return forward({type:'GET_VIDEO_STATS'},sender);
 case 'CONTROL_VIDEO':if(!isExtensionPanel(sender))throw new Error('Open the panel.');return forward({type:'CONTROL_VIDEO',action:msg.action,time:msg.time},sender);
 case 'VIDEO_STATS_UPDATE':if(siteSender(sender))notify({type:'VIDEO_STATS_UPDATE',stats:msg.stats});return {ok:true};
 case 'VIDEO_ID_FROM_PAGE':if(siteSender(sender)&&/^v[0-9a-z]+$/i.test(msg.videoId||'')){videoIdsByTab.set(sender.tab.id,msg.videoId);notify({type:'VIDEO_ID_DETECTED',videoId:msg.videoId});}return {ok:true};
 case 'GET_DETECTED_VIDEO_ID':return {videoId:videoIdsByTab.get((await selectedTab(sender))?.id)||null};
 case 'GET_WATCHING_PAGE_URL':try{return {url:validateWatchingUrl((await selectedTab(sender))?.url)};}catch{return {url:null};}
 case 'PUBLISH_INTERCEPTED':if(siteSender(sender))notify({type:'PUBLISH_UPDATE',modified:!!msg.modified});return {ok:true};
 case 'INTERCEPTED_DATA':{
   if(!siteSender(sender))return {};
   const d=msg.data;let u;try{u=new URL(d?.url);}catch{return {};}
   if(u.hostname!=='www.tiktok.com'||!/^\/tiktok\/web\/project\/post\/v1(?:\/|$)/.test(u.pathname))return {};
   let response;try{response=JSON.parse(d.resBody);}catch{return {};}
   const clean={status_code:response.status_code,single_post_resp_list:(response.single_post_resp_list||[]).slice(0,10).map(p=>({status_code:p.status_code,item_id:String(p.item_id||'')}))};
   requestLog.push({cat:'PUBLISH',ts:Date.now(),url:u.origin+u.pathname,resBody:JSON.stringify(clean)});requestLog=requestLog.slice(-100);await chrome.storage.local.set({publishLog:requestLog});notify({type:'PUBLISH_UPDATE'});return {ok:true};
 }
 case 'GET_LOG':return {log:requestLog};
 case 'GET_SESSIONS':return {sessions:[],active:{videoId:videoIdsByTab.get((await selectedTab(sender))?.id)||null}};
 case 'ANALYZE_TIKWM':if(!isExtensionPanel(sender))throw new Error('Open the extension panel.');return {ok:true,data:await analyzeTikwm(msg.url)};
 case 'DOWNLOAD_TIKWM':{
   if(!isExtensionPanel(sender))throw new Error('Open the extension panel.');
   const cached=analysisCache.get(msg.videoUrl),variant=['play','wmplay','hdplay'].includes(msg.variant)?msg.variant:null;
   const value=variant&&cached?.data?.[variant];if(!value)throw new Error('Analyze again to refresh download links.');
   const url=new URL(value);if(url.protocol!=='https:')throw new Error('Invalid download link.');
   await chrome.downloads.download({url:url.href,filename:'CompressBase-'+String(cached.data.id||'video').replace(/[^0-9a-z_-]/gi,'')+'-'+variant+'.mp4',saveAs:true});return {ok:true};
 }
 case 'OPEN_SETTINGS':if(!extensionUI(sender))throw new Error('Open the panel.');await chrome.runtime.openOptionsPage();return {ok:true};
 case 'CLEAR_LOCAL_DATA':if(sender.url!==chrome.runtime.getURL('options/options.html'))throw new Error('Open Settings.');await chrome.storage.local.clear();requestLog=[];analysisCache.clear();videoIdsByTab.clear();config=defaultConfig;await broadcastConfig();return {ok:true};
 default:return {};
 }
}
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{handle(msg||{},sender).then(respond).catch(error=>respond({ok:false,error:error.message}));return true;});
chrome.tabs.onRemoved.addListener(id=>videoIdsByTab.delete(id));
