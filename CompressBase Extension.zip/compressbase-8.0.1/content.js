/**
 * TT Analytics — Content Script (v4)
 *
 * v4: Handle TRANSCODE_COMPLETED. Fallback polling fixed
 * (correct path to status, file_key placeholder).
 */

(function () {
  'use strict';

  let config = null;
  let configSentToPage = false;
  let extensionInvalidated = false;

  // Safe message sending to background
  function safeSend(msg) {
    if (extensionInvalidated) return Promise.resolve(null);
    return chrome.runtime.sendMessage(msg).catch(err => {
      if (err?.message?.includes('Extension context invalidated')) {
        extensionInvalidated = true;
        showNotification('⚠️ Extension updated! Reload page (F5)', 'error', 15000);
      }
      return null;
    });
  }

  // ═══ INTERCEPTOR INJECTION ═══

  function injectInterceptor() {
    if (document.documentElement.dataset.maskaInterceptor) return;
    document.documentElement.dataset.maskaInterceptor = '1';
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('interceptor.js');
    s.dataset.extId = chrome.runtime.id;
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);
  }

  function replyConfigToPage() {
    if (!config) return;
    window.postMessage({ dir: 'TT_FROM_BG', msg: { type: 'CONFIG', config } }, '*');
    configSentToPage = true;
  }

  function fetchConfigFromBackground() {
    return safeSend({ type: 'GET_CONFIG' }).then(res => {
      if (res?.config) {
        config = res.config;
        replyConfigToPage();
      }
      return config;
    });
  }

  // ═══ BRIDGE: page ↔ background ═══

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.dir !== 'TT_TO_BG') return;
    const msg = e.data.msg;
    if (msg?.type === 'GET_CONFIG') {
      if (config) {
        replyConfigToPage();
      } else {
        fetchConfigFromBackground();
      }
      return;
    }
    if (['PUBLISH_INTERCEPTED','INTERCEPTED_DATA','VIDEO_ID_FROM_PAGE','FILE_KEY_FROM_PAGE'].includes(msg?.type)) safeSend(msg);
  });

  // ═══ COMMANDS FROM BACKGROUND ═══

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {

      case 'CONFIG_UPDATED':
        config = msg.config;
        replyConfigToPage();
        sendResponse({ ok: true });
        break;

      case 'SHOW_NOTIFICATION':
        showNotification(msg.text, msg.notifType || 'info', msg.duration);
        sendResponse({ ok: true });
        break;

      case 'TRANSCODE_COMPLETED':
        showNotification('✅ Transcode completed! You can publish.', 'success', 8000);
        sendResponse({ ok: true });
        break;

      default:
        sendResponse({});
    }
    return true;
  });

  async function bootstrap() {
    for (let i = 0; i < 8; i++) {
      await fetchConfigFromBackground();
      if (config) break;
      await new Promise(r => setTimeout(r, 150 * (i + 1)));
    }
    injectInterceptor();
    replyConfigToPage();
    if (!config) {
      setTimeout(fetchConfigFromBackground, 500);
      setTimeout(fetchConfigFromBackground, 2000);
    }
  }

  bootstrap();

  // ═══ NOTIFICATIONS ON PAGE ═══

  function showNotification(text, type, duration) {
    const id = 'tt-notif-' + Date.now();
    const colors = {
      info: '#1a90ff', success: '#00c853', error: '#ff1744', warning: '#ff9100'
    };

    // Shift notifications down if there are others
    const existing = document.querySelectorAll('[id^="tt-notif-"]');
    const topOffset = 10 + existing.length * 46;

    const div = document.createElement('div');
    div.id = id;
    div.style.cssText = 'position:fixed;top:' + topOffset + 'px;right:10px;z-index:999999;' +
      'padding:10px 16px;border-radius:8px;font-size:13px;font-family:sans-serif;' +
      'color:white;background:' + (colors[type] || colors.info) + ';' +
      'box-shadow:0 4px 12px rgba(0,0,0,0.3);transition:opacity 0.3s;opacity:1;';
    div.textContent = '[Maska] ' + text;
    document.body.appendChild(div);

    setTimeout(() => {
      div.style.opacity = '0';
      setTimeout(() => div.remove(), 300);
    }, duration || 3000);
  }

  console.log('[TT] Content script v3.1 loaded.');
})();
