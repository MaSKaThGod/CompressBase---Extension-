(function () {
  'use strict';

  let config = null;
  let configReady = false;

  const FALLBACK_CONFIG = {
    enabled: true,
    methods: {
      modifyPublishBody: true,
      privateFirst: false,
      modifyCloudEdit: false,
      modifyEntryPoint: false,
      modifySinglePostInfo: false,
      removeDraft: true,
      removeCloudEdit: true,
      spoofDevicePlatform: false,
      addHDParams: false,
      forceVideoCanvas: false,
      spoofAid: false,
    },
    params: {
      cloudEditHeight: 1080,
      cloudEditWidth: 1080,
      enterPostPageFrom: 2,
      singlePostHeight: 0,
      singlePostWidth: 0,
    },
  };

  // ═══ CONFIG ═══

  function requestConfig() {
    window.postMessage({ dir: 'TT_TO_BG', msg: { type: 'GET_CONFIG' } }, '*');
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.dir !== 'TT_FROM_BG') return;
    const msg = e.data.msg;
    if (msg?.type === 'CONFIG' && msg.config) {
      config = msg.config;
      configReady = true;
    }
  });

  requestConfig();
  let configAttempts = 0;
  const configTimer = setInterval(() => {
    if (configReady) {
      clearInterval(configTimer);
      return;
    }
    if (configAttempts++ > 40) {
      clearInterval(configTimer);
      return;
    }
    requestConfig();
  }, 200);

  function getConfig() {
    return config || FALLBACK_CONFIG;
  }

  function hasRealConfig() {
    return configReady && !!config;
  }

  function toBg(msg) {
    window.postMessage({ dir: 'TT_TO_BG', msg }, '*');
  }

  // Resolve the item attached to the actual video element, including FYP
  // cards which do not render a public /video/ link in the DOM.
  function itemUrlFromProps(value, depth = 0) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || depth > 5) return '';
    const itemId = value.aweme_id || value.id;
    if (/^\d{15,22}$/.test(String(itemId || '')) && (value.video || value.author)) {
      const author = value.author?.uniqueId || value.author?.unique_id || '_';
      return 'https://www.tiktok.com/@' + encodeURIComponent(author) + '/video/' + itemId;
    }
    for (const key of ['item', 'itemInfo', 'itemStruct', 'aweme', 'awemeInfo', 'itemData', 'data', 'videoData']) {
      const result = itemUrlFromProps(value[key], depth + 1);
      if (result) return result;
    }
    return '';
  }
  function resolveFypItem(video) {
    let node = video;
    for (let level=0; node && level<14; level++, node=node.parentElement) {
      for (const key of Object.keys(node)) {
        if (key.startsWith('__reactProps$')) {
          const result = itemUrlFromProps(node[key]);
          if (result) return result;
        }
        if (key.startsWith('__reactFiber$') || key.startsWith('__reactInternalInstance$')) {
          let fiber = node[key];
          for (let step=0; fiber && step<18; step++,fiber=fiber.return) {
            const result = itemUrlFromProps(fiber.memoizedProps) || itemUrlFromProps(fiber.pendingProps);
            if (result) return result;
          }
        }
      }
    }
    return '';
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.type !== 'CB_RESOLVE_FYP') return;
    const token = event.data.token;
    if (typeof token !== 'string' || !/^[a-z0-9-]{1,80}$/i.test(token)) return;
    const video = document.querySelector('video[data-cb-resolve="' + token + '"]');
    if (!video) return;
    const url = resolveFypItem(video);
    window.postMessage({type:'CB_RESOLVED_FYP',token,url},'*');
  });

  // ═══ FILE_KEY DETECTOR ═══

  function detectFileKey(url, body) {
    if (!url.includes('transcode/result')) return;
    if (!body) return;
    let text = body;
    if (typeof body !== 'string') {
      try {
        if (body instanceof ArrayBuffer || body instanceof Uint8Array) {
          text = new TextDecoder('utf-8').decode(body);
        } else {
          return;
        }
      } catch (e) { return; }
    }
    try {
      const data = JSON.parse(text);
      if (data.video_info && Array.isArray(data.video_info)) {
        for (const vi of data.video_info) {
          if (vi.file_key && vi.file_key.startsWith('file_')) {
            console.log('[TT-int] 🔑 file_key found:', vi.file_key);
            toBg({
              type: 'FILE_KEY_FROM_PAGE',
              fileKey: vi.file_key,
              duration: vi.original_duration_ms || 0
            });
          }
        }
      }
    } catch (e) { /* not JSON — OK */ }
  }

  // ═══ VIDEO_ID DETECTOR ═══

  const seenIds = new Set();

  function detectVideoId(url, body) {
    // Из URL
    const m1 = url.match(/video_id=(v[0-9a-z]+)/i);
    if (m1 && !seenIds.has(m1[1])) {
      seenIds.add(m1[1]);
      toBg({ type: 'VIDEO_ID_FROM_PAGE', videoId: m1[1] });
    }

    // Из тела запроса
    if (body && typeof body === 'string') {
      const m2 = body.match(/"video_id"\s*:\s*"(v[0-9a-z]+)"/i);
      if (m2 && !seenIds.has(m2[1])) {
        seenIds.add(m2[1]);
        toBg({ type: 'VIDEO_ID_FROM_PAGE', videoId: m2[1] });
      }
    }
  }

  // ═══ URL SPOOFING ═══

  function spoofUrl(url) { return url; }

  // ═══ MODIFY PUBLISH BODY ═══

  function isFinalPostUrl(url) {
    try {
      const parsed = new URL(url, window.location.href);
      return parsed.origin === 'https://www.tiktok.com' &&
        /^\/tiktok\/web\/project\/post\/v1(?:\/|$)/.test(parsed.pathname);
    } catch (e) {
      return false;
    }
  }

  function modifyPublishBody(url, body) {
    const cfg = getConfig();
    if (!isFinalPostUrl(url) || typeof body !== 'string' ||
        !cfg.enabled || !cfg.methods?.modifyPublishBody) return body;
    try {
      const data = JSON.parse(body);
      const features = data.feature_common_info_list;
      const posts = data.single_post_req_list;
      // Restrict this method to the single-video, single-song layout supplied
      // in the working reference. Unknown layouts pass through unchanged.
      if (!Array.isArray(features) || features.length !== 1 ||
          !Array.isArray(posts) || posts.length !== 1 ||
          ![2, 3].includes(data.post_common_info?.post_type)) return body;
      const edit = features[0].vedit_common_info;
      const post = posts[0];
      const info = post.single_post_feature_info;
      const project = info?.cover_info?.coverProject?.sourceProject;
      if (!edit?.video_id || edit.video_id !== post.video_id || edit.application !== 2 ||
          (!info?.music_info || typeof info.music_info !== 'object' || Array.isArray(info.music_info)) ||
          typeof edit.tiktok_snap_shot_lite_params !== 'string' ||
          !Array.isArray(project?.assets) || !Array.isArray(project?.tracks)) return body;
      const snapshot = JSON.parse(edit.tiktok_snap_shot_lite_params);
      if (!Array.isArray(snapshot.Elements)) return body;
      const audioElements = snapshot.Elements.filter(e => e?.Type === 'audio');
      const videoElements = snapshot.Elements.filter(e => e?.Type === 'video');
      if (audioElements.length !== 1 || videoElements.length !== 1 ||
          videoElements[0].Source !== 'vid://' + edit.video_id) return body;
      const audio = audioElements[0];
      const assets = project.assets.filter(a => a.type === 'audio' &&
        a.url?.http === audio.Source && a.metaInfo?.musicId);
      if (assets.length !== 1) return body;
      const asset = assets[0];
      const song = asset.metaInfo;
      if (info.music_info.music_id_string &&
          String(info.music_info.music_id_string) !== String(song.musicId)) return body;
      if (typeof song.authorName !== 'string' || typeof asset.name !== 'string' ||
          typeof song.coverUrl !== 'string' || !Number.isFinite(audio.StartTime) ||
          !Number.isFinite(audio.EndTime) || audio.EndTime <= audio.StartTime ||
          !Number.isFinite(audio.Volume) || audio.Volume < 0 || audio.Volume > 1) return body;
      const audioTracks = project.tracks.filter(t => t.type === 'audio');
      if (audioTracks.length !== 1 || !Array.isArray(audioTracks[0].clips) ||
          audioTracks[0].clips.length !== 1) return body;
      const clip = audioTracks[0].clips[0];
      if (clip.assetId !== asset.id || !clip.props?.audio) return body;

      // The working example keeps a tiny nonzero song volume, consistently in
      // the render snapshot, editor project, and percentage-based music_info.
      const volume = audio.Volume === 0 ? 0.001122 : audio.Volume;
      audio.Volume = volume;
      clip.props.audio.volume = volume;
      const music = info.music_info;
      Object.assign(music, {
        music_begin_time: audio.StartTime,
        music_end_time: audio.EndTime,
        music_type: 1,
        music_author: song.authorName,
        music_title: asset.name,
        music_album: song.coverUrl,
        music_volume: String(Number((volume * 100).toFixed(8))),
        music_id_string: String(song.musicId),
        music_url: audio.Source
      });
      // Preserve the full video render project and actual media metadata.
      edit.tiktok_snap_shot_lite_params = JSON.stringify(snapshot);
      delete edit.draft;
      delete info.vedit_segment_info;
      data.post_common_info.post_type = 3;
      info.is_upload_audio_track = true;
      const result = JSON.stringify(data);
      if (result === body) return body;
      const changes = ['working-reference: post_type=3', 'music_info=selected song metadata',
        'is_upload_audio_track=true', 'draft and vedit_segment_info removed',
        'song volume=' + music.music_volume];
      console.log('[Maska-int] Working-reference publish method:', changes);
      toBg({ type: 'PUBLISH_INTERCEPTED', modified: true, changes,
        usedFallback: !hasRealConfig() });
      return result;
    } catch (e) {
      console.warn('[Maska-int] Publish method skipped; original body preserved:', e);
      return body;
    }
  }

  // ═══ FETCH INTERCEPTION ═══

  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    let [input, init] = args;
    let url = typeof input === 'string' ? input : (input instanceof URL ? input.href : (input?.url || ''));
    const resolvedUrl = new URL(url, window.location.href);
    url = resolvedUrl.href;

    // Пропускаем не-TikTok
    if (!url.includes('tiktok.com') && !url.includes('tiktokcdn.com')) {
      return _fetch.apply(this, args);
    }

    // Детектим video_id
    detectVideoId(url, init?.body && typeof init.body === 'string' ? init.body : null);

    // Детектим file_key из нативного transcode/result
    detectFileKey(url, init?.body && typeof init.body === 'string' ? init.body : null);

    // === v5: СПУФИНГ URL (device_platform) ===
    const spoofedUrl = spoofUrl(url);
    if (spoofedUrl !== url) {
      if (typeof input === 'string' || input instanceof URL) {
        input = spoofedUrl;
      } else if (input?.url) {
        input = new Request(spoofedUrl, input);
      }
      url = spoofedUrl;
    }

    // Модифицируем publish body
    if (isFinalPostUrl(url)) {
      if (typeof init?.body === 'string') {
        init = { ...init, body: modifyPublishBody(url, init.body) };
      } else if (input instanceof Request && init?.body === undefined && !input.bodyUsed) {
        // Read a clone so an inspection failure leaves the original request usable.
        try {
          const body = await input.clone().text();
          const modifiedBody = modifyPublishBody(url, body);
          if (modifiedBody !== body) {
            input = new Request(input, { body: modifiedBody });
          }
        } catch (e) {
          console.warn('[Maska-int] Could not inspect post request:', e);
        }
      }
    }

    try {
      const response = await _fetch.call(this, input, init);
      if (!isFinalPostUrl(url)) return response;
      const clone = response.clone();

      // Log asynchronously
      (async () => {
        try {
          const ct = clone.headers.get('content-type') || '';
          let resBody = null;
          if (ct.includes('json') || ct.includes('text')) {
            resBody = await clone.text();
          }

          // Look for video_id in response too
          if (resBody) detectVideoId(url, resBody);

          toBg({
            type: 'INTERCEPTED_DATA',
            data: {
              url, method: init?.method || 'GET', ts: Date.now(),
              reqBody: init?.body && typeof init.body === 'string' ? init.body.slice(0, 5000) : null,
              resBody: resBody ? resBody.slice(0, 5000) : null,
              status: response.status,
            }
          });
        } catch (e) {}
      })();

      return response;
    } catch (e) { throw e; }
  };

  // ═══ XHR INTERCEPTION ═══

  const _xhrOpen = XMLHttpRequest.prototype.open;
  const _xhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ttUrl = url;
    this._ttMethod = method;
    // === v5: URL SPOOFING ===
    const spoofedUrl = spoofUrl(url);
    if (spoofedUrl !== url) {
      this._ttUrl = spoofedUrl;
      return _xhrOpen.call(this, method, spoofedUrl, ...rest);
    }
    return _xhrOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const url = this._ttUrl || '';

    if (url.includes('tiktok.com') || url.includes('tiktokcdn.com')) {
      detectVideoId(url, body && typeof body === 'string' ? body : null);
      detectFileKey(url, body);

      // Modify publish
      if (typeof body === 'string' && isFinalPostUrl(url)) {
        body = modifyPublishBody(url, body);
      }

      this.addEventListener('load', () => {
        if (!isFinalPostUrl(url)) return;
        try {
          if (this.responseText) detectVideoId(url, this.responseText);
          toBg({
            type: 'INTERCEPTED_DATA',
            data: {
              url, method: this._ttMethod || 'GET', ts: Date.now(),
              reqBody: body && typeof body === 'string' ? body.slice(0, 5000) : null,
              resBody: this.responseText ? this.responseText.slice(0, 5000) : null,
              status: this.status,
            }
          });
        } catch (e) {}
      });
    }

    return _xhrSend.call(this, body);
  };

  console.log('[Maska-int] Interceptor ready');
})();
