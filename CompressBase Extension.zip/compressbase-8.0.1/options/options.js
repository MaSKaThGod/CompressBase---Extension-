'use strict';
const $ = id => document.getElementById(id);
$('clear').onclick = async () => {
  const result = await chrome.runtime.sendMessage({type: 'CLEAR_LOCAL_DATA'});
  $('status').textContent = result.ok ? 'Local extension data cleared.' : result.error;
};
