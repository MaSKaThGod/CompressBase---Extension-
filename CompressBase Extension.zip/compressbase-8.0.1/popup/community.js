(function(){
'use strict';
document.addEventListener('DOMContentLoaded',async()=>{
 const dialog=document.getElementById('communityDialog');
 const join=document.getElementById('joinCommunity');
 const noThanks=document.getElementById('declineCommunity');
 let dismissed=false;
 async function dismiss(){
   if(dismissed)return;dismissed=true;
   await chrome.storage.local.set({communityPromptDismissed:true});
   if(dialog.open)dialog.close();
 }
 join.addEventListener('click',async()=>{
   join.disabled=true;
   try{await chrome.tabs.create({url:'https://discord.gg/compress'});await dismiss();}
   catch{join.disabled=false;document.getElementById('communityStatus').textContent='Could not open Discord. Try again or choose No Thanks.';}
 });
 noThanks.addEventListener('click',dismiss);
 dialog.addEventListener('cancel',event=>{event.preventDefault();dismiss();});
 try{const saved=await chrome.storage.local.get('communityPromptDismissed');if(!saved.communityPromptDismissed)dialog.showModal();}catch{}
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.communityPromptDismissed?.newValue){dismissed=true;if(dialog.open)dialog.close();}});
});
})();