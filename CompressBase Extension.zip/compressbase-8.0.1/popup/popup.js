(function(){
'use strict';
let config=null,stats=null,videoId='';
let watchingUrl='', analyzedUrl='', analyzeGeneration=0;
const el=id=>document.getElementById(id);
const text=(id,value)=>{el(id).textContent=value??'—';};
const send=msg=>chrome.runtime.sendMessage(msg);
function notice(message){text('notice',message);setTimeout(()=>text('notice',''),3000);}
function power(){const on=!!config?.enabled;el('masterToggle').checked=on;document.body.classList.toggle('enabled',on);text('powerLabel',on?'ON':'OFF');text('connectionTitle','Method');text('connectionText',on?'Publishing method enabled':'Publishing method disabled');}
function updateWatchingVideo(nextUrl){
  const nextId=nextUrl.match(/\/video\/(\d+)/)?.[1];
  const currentId=watchingUrl.match(/\/video\/(\d+)/)?.[1];
  // Missing links during FYP refresh and username aliases are not new videos.
  // Keep the result until a different numeric TikTok item ID is confirmed.
  if(!nextId || nextId===currentId)return;
  watchingUrl=nextUrl;analyzedUrl='';analyzeGeneration++;
  el('analysisUrl').value='';
  el('analysisResult').hidden=true;
  text('analyzeStatus','Ready to analyze the current video.');
  el('analyze').disabled=false;
}
function render(s){if(!s)return;stats=s;
const nextUrl=s.videoUrl||'';
const watchedId=nextUrl.match(/\/video\/(\d+)/)?.[1];
if(watchedId){videoId=watchedId;el('videoId').value=videoId;el('copy').disabled=false;}
updateWatchingVideo(nextUrl);
el('fps').title='Estimated presented frame rate (≈), not guaranteed source-file FPS. Measurement resets for each video.';
const watching=!!s.watching;text('quality',watching?s.qualityTier:'—');text('fps',watching&&s.fps!=='—'?String(s.fps).replace(/\s*fps$/i,'')+' FPS':'—');text('videoRes',s.videoResolution);text('screenRes',s.screenResolution);text('state',s.state||'No video');text('buffer',s.buffer);const fmt=n=>{n=Math.max(0,Number(n)||0);return String(Math.floor(n/60)).padStart(2,'0')+':'+String(Math.floor(n%60)).padStart(2,'0');};el('time').replaceChildren(document.createTextNode(fmt(s.currentSec)+' '));const end=document.createElement('em');end.textContent='/ '+fmt(s.durationSec);el('time').append(end);const valid=watching&&Number(s.durationSec)>0;el('play').disabled=!valid;el('seek').disabled=!valid;el('seek').max=s.durationSec||100;el('seek').value=s.currentSec||0;el('play').innerHTML=/playing/i.test(s.state||'')?"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M7 5h3.5v14H7zm6.5 0H17v14h-3.5z\" fill=\"currentColor\"/></svg>":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M8 5.5v13L19 12Z\" fill=\"currentColor\"/></svg>";}
function findVideoId(value) {
  if (typeof value !== 'string') return '';
  const match = value.match(/(?:video_id["'\s:=]+|vid:\/\/)(v[0-9a-z]+)/i);
  if (match) return match[1];
  try {
    const decoded = decodeURIComponent(value);
    if (decoded !== value) return findVideoId(decoded);
  } catch (_) {}
  return '';
}
async function refresh(){
  try {
    const [logs,runs,current] = await Promise.all([
      send({type:'GET_LOG',filter:{limit:3000}}),
      send({type:'GET_SESSIONS'}),send({type:'GET_DETECTED_VIDEO_ID'})
    ]);
    const log=logs.log||[];
    let fromLog='';
    for(const entry of [...log].reverse()) {
      fromLog=findVideoId(entry.reqBody)||findVideoId(entry.resBody)||findVideoId(entry.url);
      if(fromLog)break;
    }
    videoId=watchingUrl.match(/\/video\/(\d+)/)?.[1]||current?.videoId||runs.active?.videoId||fromLog||
      [...(runs.sessions||[])].reverse().find(s=>s.videoId)?.videoId||videoId;
    el('videoId').value=videoId||'Waiting for video';
    el('copy').disabled=!videoId;
    const ids=new Set();
    for(const e of log){
      if(e.cat!=='PUBLISH'||!e.resBody)continue;
      try{const d=JSON.parse(e.resBody);if(d.status_code!==0)continue;
        for(const p of d.single_post_resp_list||[])if(p.status_code===0&&p.item_id)ids.add(p.item_id);
      }catch{}
    }
    text('publishCount',String(ids.size));
  }catch{notice('Could not refresh');}
}

function displayAnalysis(data){
  const flag=data.is_nff_or_nr;
  text('shadowban','Shadowban: '+(flag===true?'Yes':flag===false?'No':'Unknown'));
  el('shadowban').className='shadowban'+(flag===true?' yes':flag===false?' no':'');
  const number=v=>v==null?'—':Number(v).toLocaleString();
  const size=v=>v==null?'—':(Number(v)/1048576).toFixed(2)+' MiB ('+number(v)+' bytes)';
  const date=data.create_time?new Date(Number(data.create_time)*1000).toLocaleString(undefined,{timeZone:'America/Toronto',timeZoneName:'short'}): '—';
  const fields=[['Views',number(data.play_count)],['Likes',number(data.digg_count)],['Comments',number(data.comment_count)],['Shares',number(data.share_count)],['Downloads',number(data.download_count)],['Saves',number(data.collect_count)],['Create date',date],['Music title',data.music_info?.title],['Music author',data.music_info?.author],['Author',data.author?.nickname],['Username',data.author?.unique_id],['Duration',data.duration==null?'—':data.duration+' seconds'],['Video ID',data.id],['Aweme ID',data.aweme_id],['Region',data.region],['Title',data.title],['Video size',size(data.size)],['Watermark size',size(data.wm_size)],['HD size',size(data.hd_size)]];
  const container=el('analysisFields');container.replaceChildren();
  for(const [label,value] of fields){const row=document.createElement('div');row.className='analysis-field';const name=document.createElement('span');name.textContent=label;const val=document.createElement('strong');val.textContent=value??'—';row.append(name,val);container.append(row);}
  document.querySelectorAll('[data-download]').forEach(button=>{button.disabled=!data[button.dataset.download];});
  el('analysisResult').hidden=false;
}
async function runAnalysis(){
  if(!el('analysisDialog').open){document.body.classList.add('modal-open');el('analysisDialog').showModal();}
  if(!watchingUrl){
    text('analyzeStatus','Finding the current video…');
    try {
      const latest=await send({type:'GET_VIDEO_STATS'});
      if(latest)render(latest);
      if(!watchingUrl){const result=await send({type:'GET_WATCHING_PAGE_URL'});if(result?.url){watchingUrl=result.url;}}
    } catch (_) {}
  }
  const manual=el('analysisUrl').value.trim();
  if(manual)watchingUrl=manual;
  if(!watchingUrl){text('analyzeStatus','Could not detect a video link on this page. Paste its TikTok link below, then select Analyze link.');el('analysisUrl').focus();return;}
  const requestedUrl=watchingUrl, generation=++analyzeGeneration;
  el('analyze').disabled=true;el('analysisResult').hidden=true;text('analyzeStatus','Requesting TikWM…');
  try{const result=await send({type:'ANALYZE_TIKWM',url:requestedUrl});
    if(generation!==analyzeGeneration||requestedUrl!==watchingUrl)return;
    if(!result?.ok)throw new Error(result?.error||'Analysis failed.');
    analyzedUrl=requestedUrl;displayAnalysis(result.data);text('analyzeStatus','');
  }catch(e){if(generation===analyzeGeneration)text('analyzeStatus',e.message);}
  finally{if(generation===analyzeGeneration)el('analyze').disabled=false;}
}
document.addEventListener('DOMContentLoaded',async()=>{
el('minimize').addEventListener('click',()=>window.parent.postMessage({type:'CB_MINIMIZE'},'*'));
el('analyze').disabled=false;
el('analyze').addEventListener('click',runAnalysis);
el('analyzeLink').addEventListener('click',runAnalysis);
el('closeAnalysis').addEventListener('click',()=>el('analysisDialog').close());
el('analysisDialog').addEventListener('close',()=>document.body.classList.remove('modal-open'));
el('analysisDialog').addEventListener('click',event=>{
  if(event.target!==el('analysisDialog'))return;
  const rect=el('analysisDialog').getBoundingClientRect();
  if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)el('analysisDialog').close();
});
document.querySelectorAll('[data-download]').forEach(button=>button.addEventListener('click',async()=>{
  if(!analyzedUrl||analyzedUrl!==watchingUrl)return;
  try{const result=await send({type:'DOWNLOAD_TIKWM',videoUrl:analyzedUrl,variant:button.dataset.download});if(!result?.ok)throw new Error(result?.error||'Download failed.');}
  catch(e){text('analyzeStatus',e.message);}
}));
try{config=(await send({type:'GET_CONFIG'})).config;power();el('masterToggle').disabled=false;}catch{ text('connectionTitle','Unavailable');text('connectionText','Reload the extension and TikTok');}
el('masterToggle').addEventListener('change',async()=>{const previous=config.enabled;config.enabled=el('masterToggle').checked;config.methods={...config.methods,privateFirst:false,modifyPublishBody:true};power();try{await send({type:'SET_CONFIG',config});}catch{config.enabled=previous;power();notice('Could not save');}});
el('copy').addEventListener('click',async()=>{if(!videoId)return;try{await navigator.clipboard.writeText(videoId);notice('Video ID copied');}catch{notice('Copy unavailable');}});
for(const [id,action] of [['play','toggle'],['seek','seek']])el(id).addEventListener(id==='seek'?'change':'click',async()=>{try{const r=await send({type:'CONTROL_VIDEO',action,time:Number(el('seek').value)});if(!r?.ok)notice('No video available');else if(r.stats)render(r.stats);}catch{notice('Video unavailable');}});
await refresh();try{render(await send({type:'GET_VIDEO_STATS'}));}catch{}
setInterval(refresh,5000);
});
chrome.runtime.onMessage.addListener(msg=>{if(msg.type==='VIDEO_STATS_UPDATE')render(msg.stats);if(msg.type==='VIDEO_ID_DETECTED'){videoId=msg.videoId;el('videoId').value=videoId;}if(msg.type==='PUBLISH_UPDATE')refresh();if(msg.type==='CONFIG_UPDATED'){config=msg.config;power();}});
})();