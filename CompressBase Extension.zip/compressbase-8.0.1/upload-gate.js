(function(){
'use strict';
if(window!==window.top)return;
let config=null,pending=null;
const replayEvents=new WeakSet();
const loadConfig=()=>chrome.runtime.sendMessage({type:'GET_CONFIG'}).then(r=>{config=r?.config||null;return config;}).catch(()=>null);
loadConfig();
const isUploadPage=()=>/(?:^|\/)(?:upload)(?:\/|$)/i.test(location.pathname);
const isVideo=file=>file && (file.type.startsWith('video/') || /\.(mp4|mov|m4v|webm|mkv|avi)$/i.test(file.name));
function chooseInput(original){
 if(original?.isConnected)return original;
 return [...document.querySelectorAll('input[type="file"]')].find(input=>/video|mp4/i.test(input.accept));
}
function replay(job,file){
 const transfer=new DataTransfer();transfer.items.add(file);
 if(job.kind==='input'){
   const input=chooseInput(job.target);if(!input)throw new Error('TikTok replaced its file picker. Select the prepared file manually.');
   input.files=transfer.files;
   for(const type of ['input','change']){const event=new Event(type,{bubbles:true,composed:true});replayEvents.add(event);input.dispatchEvent(event);}
 }else{
   if(!job.target?.isConnected)throw new Error('The upload drop zone changed. Select the prepared file manually.');
   for(const type of ['dragenter','dragover','drop']){const event=new DragEvent(type,{bubbles:true,cancelable:true,composed:true,dataTransfer:transfer});replayEvents.add(event);job.target.dispatchEvent(event);}
 }
}
function finish(job,file){
 if(pending!==job)return;
 try{replay(job,file);job.host?.remove();job.port?.close();pending=null;}
 catch(error){job.port?.postMessage({type:'REPLAY_ERROR',error:error.message});}
}
async function showPrompt(job){
 const cfg=config||await loadConfig();
 if(pending!==job)return;
 if(!cfg?.enabled){finish(job,job.file);return;}
 const host=document.createElement('div');job.host=host;
 host.style.cssText='position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;background:rgba(3,9,7,.78);backdrop-filter:blur(6px)';
 host.setAttribute('role','dialog');host.setAttribute('aria-modal','true');host.setAttribute('aria-label','CompressBase upload method');
 const shadow=host.attachShadow({mode:'open'});
 const style=document.createElement('style');style.textContent='iframe{width:min(650px,calc(100vw - 28px));height:min(780px,calc(100vh - 28px));border:1px solid #3a5445;border-radius:16px;background:#101718;box-shadow:0 28px 100px #0009}';
 const frame=document.createElement('iframe');frame.src=chrome.runtime.getURL('upload/patcher.html');frame.title='CompressBase upload method';
 frame.onload=()=>{
   if(pending!==job)return;
   const channel=new MessageChannel();job.port=channel.port1;
   job.port.onmessage=event=>{
     if(pending!==job)return;
     const message=event.data;
     if(message?.type==='ORIGINAL')finish(job,job.file);
     else if(message?.type==='PATCHED'&&message.file instanceof File&&message.file.size>0){
       if(!config?.enabled){finish(job,job.file);return;}
       finish(job,message.file);
     }
   };
   frame.contentWindow.postMessage({type:'CB_UPLOAD_INIT',file:job.file},new URL(frame.src).origin,[channel.port2]);
   frame.focus();
 };
 shadow.append(style,frame);(document.body||document.documentElement).append(host);
}
function capture(event){
 if(replayEvents.has(event)||!isUploadPage()||config?.enabled===false)return;
 const input=event.target instanceof HTMLInputElement&&event.target.type==='file'?event.target:null;
 const list=event.type==='drop'?event.dataTransfer?.files:input?.files;
 if(input&&pending?.target===input&&(!list||list.length===0)){event.stopImmediatePropagation();event.preventDefault();return;}
 if(!list||list.length!==1||!isVideo(list[0]))return;
 // Intercept before TikTok's React listeners receive this selection.
 event.stopImmediatePropagation();event.preventDefault();
 if(pending)return;
 const job={file:list[0],target:input||event.target,kind:input?'input':'drop',host:null,port:null};pending=job;
 if(input)input.value='';
 showPrompt(job).catch(()=>finish(job,job.file));
}
window.addEventListener('change',capture,true);
window.addEventListener('drop',capture,true);
// Some uploaders consume input before change. Hold that event as well.
window.addEventListener('input',capture,true);
chrome.runtime.onMessage.addListener(message=>{
 if(message.type!=='CONFIG_UPDATED')return;
 config=message.config;
 if(!config?.enabled&&pending){pending.port?.postMessage({type:'ABORT'});finish(pending,pending.file);}
});
window.addEventListener('pagehide',()=>{pending?.port?.postMessage({type:'ABORT'});pending?.port?.close();pending?.host?.remove();pending=null;});
})();