import { patchVideo, prepareMetadata } from '../vendor/compressbase/method-api/client.mjs';
import { downscaleVideo } from '../vendor/compressbase/method-api/downscale.mjs';
import { processingPlan, selectSmallerSource } from './processing-policy.mjs';
const $=id=>document.getElementById(id), cards=[...document.querySelectorAll('[data-variant]')];
let port,file,controller,outputUrl,finished=false,optimize=false;
const message=text=>{$('message').textContent=String(text);};
function setBusy(value){for(const element of [...cards,$('original'),$('close'),$('optimize')])element.disabled=value;$('cancel').hidden=!value;$('original').hidden=value;}
function original(){if(!port||finished)return;finished=true;controller?.abort();port.postMessage({type:'ORIGINAL'});}
$('original').onclick=original;$('close').onclick=original;
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!controller)original();});
$('optimize').onclick=()=>{optimize=!optimize;$('optimize').setAttribute('aria-pressed',String(optimize));};
$('cancel').onclick=()=>controller?.abort(new DOMException('Cancelled. Choose another variant or use your original file.','AbortError'));
function showProgress(fraction){const p=Math.round(Math.max(0,Math.min(1,fraction))*100);$('progress').value=p;$('percent').textContent=p+'%';}
function onStatus(text){
  const value=String(text).toLowerCase();
  $('status').textContent=value.includes('patch')?'Applying your variant…':value.includes('check')||value.includes('reading')?'Checking video…':value.includes('loading')?'Starting the video optimizer…':optimize?'Optimizing file size…':'Preparing video…';
}
window.addEventListener('message',event=>{
  if(event.source!==parent||event.data?.type!=='CB_UPLOAD_INIT'||port)return;
  try{if(!/(^|\.)tiktok\.com$/.test(new URL(event.origin).hostname))return;}catch{return;}
  if(!event.ports[0]||!(event.data.file instanceof File))return;
  port=event.ports[0];file=event.data.file;
  $('filename').textContent=file.name;$('filesize').textContent=(file.size/1048576).toFixed(2)+' MiB';
  cards.forEach(card=>card.disabled=false);
  port.onmessage=event=>{
    if(event.data?.type==='ABORT')controller?.abort();
    if(event.data?.type==='REPLAY_ERROR'){finished=false;setBusy(false);message(event.data.error+' Download the prepared file or choose Cancel to use the original.');}
  };
});
async function runVariant(postingDevice){
  if(!file||!port||controller||finished)return;
  controller=new AbortController();setBusy(true);$('download').hidden=true;$('progressArea').hidden=false;showProgress(0);message('Your original remains available until the prepared file is ready.');
  cards.forEach(card=>card.classList.toggle('selected',card.dataset.variant===postingDevice));
  try{
    const cfg=await chrome.runtime.sendMessage({type:'GET_CONFIG'}).catch(()=>null);
    if(!cfg?.config?.enabled){original();return;}
    controller.signal.throwIfAborted();
    const isMp4=/\.mp4$/i.test(file.name);let resolution;
    if(isMp4){
      onStatus('Reading metadata');
      try{resolution=(await prepareMetadata(file,{postingDevice})).manifest.resolution;}
      catch(error){if(error.message.includes('already contains'))throw error;}
    }
    const plan=processingPlan({isMp4,resolution,optimize});
    let source=file;
    if(plan.encode){
      const encoded=await downscaleVideo(file,{
        signal:controller.signal,onStatus,frameLiteQuality:plan.frameLiteQuality,
        assetsBaseURL:new URL('../vendor/compressbase/',import.meta.url).href,
        onProgress:f=>showProgress(f*.94)
      });
      source=selectSmallerSource(file,encoded,plan);
      if(source===file)message('This file is already compact. Keeping its original media quality.');
      else message('Prepared locally: '+(file.size/1048576).toFixed(2)+' → '+(source.size/1048576).toFixed(2)+' MiB');
    }
    controller.signal.throwIfAborted();showProgress(.95);
    const output=await patchVideo(source,{postingDevice,signal:AbortSignal.any([controller.signal,AbortSignal.timeout(180000)]),onStatus});
    controller.signal.throwIfAborted();
    const patched=new File([output],file.name.replace(/\.[^.]+$/,'')+'_patched.mp4',{type:'video/mp4',lastModified:Date.now()});
    if(outputUrl)URL.revokeObjectURL(outputUrl);outputUrl=URL.createObjectURL(patched);
    $('download').href=outputUrl;$('download').download=patched.name;$('download').hidden=false;showProgress(1);
    const latest=await chrome.runtime.sendMessage({type:'GET_CONFIG'}).catch(()=>null);
    if(!latest?.config?.enabled){original();return;}
    $('status').textContent='Ready — returning your video to TikTok.';finished=true;
    port.postMessage({type:'PATCHED',file:patched});
  }catch(error){message(error.message||'Processing stopped. Try another variant or use your original.');$('status').textContent='Stopped';}
  finally{controller=null;if(!finished)setBusy(false);}
}
cards.forEach(card=>card.onclick=()=>runVariant(card.dataset.variant));
window.addEventListener('pagehide',()=>{controller?.abort();if(outputUrl)URL.revokeObjectURL(outputUrl);});
