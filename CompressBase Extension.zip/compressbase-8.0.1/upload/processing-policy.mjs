export function processingPlan({isMp4,resolution,optimize}) {
  const needsDownscale=!!resolution && Math.min(resolution.width,resolution.height)>1080;
  return {encode:!!optimize||!isMp4||!resolution||needsDownscale,needsDownscale,
    keepOriginalIfLarger:!!optimize&&!!isMp4&&!!resolution&&!needsDownscale,
    frameLiteQuality:optimize?'balanced':undefined};
}
export function selectSmallerSource(original,encoded,plan) {
  return plan.keepOriginalIfLarger&&encoded.size>=original.size?original:encoded;
}
