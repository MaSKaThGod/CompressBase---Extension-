/**
 * Maska Method — live TikTok playback stats (FYP + video page)
 */
(function () {
  'use strict';

  if (window !== window.top) return;

  const POLL_MS = 350;
  const LOCK_RELEASE_MS = 12000;

  let lockedVideo = null;
  let lockLostAt = 0;
  let trackedVideo = null;
  let rvfHandle = null;
  let fpsSamples = [];
  let lastMediaTime = null;
  let lastStaticKey = '';
  let lastPushed = null;
  let trackedSource = '';
  let lastPresentedFrames = null;
  let cachedFps = '—';

  function formatTime(sec) {
    if (!isFinite(sec) || sec < 0) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ':' + String(s).padStart(2, '0');
  }

  const STANDARD_TIERS = [360, 480, 540, 720, 1080, 2160];

  /**
   * Map decoded pixel size → playback tier (nearest standard, not ceiling).
   * Portrait TikTok: use width (540×960 → 540p).
   */
  function tierFromDimensions(w, h) {
    if (!w || !h) return null;
    const portrait = h > w * 1.05;
    const key = portrait ? w : h;
    if (key >= 3800) return '4K';

    let nearest = STANDARD_TIERS[0];
    let diff = Math.abs(key - nearest);
    for (const t of STANDARD_TIERS) {
      const d = Math.abs(key - t);
      if (d < diff) {
        diff = d;
        nearest = t;
      }
    }
    if (diff > 120) return null;
    if (nearest >= 2160) return '4K';
    return nearest + 'p';
  }

  function snapTierLabel(n) {
    const v = parseInt(n, 10);
    if (!v) return null;
    if (v >= 2160) return '4K';
    if (v >= 1080) return '1080p';
    if (v >= 720) return '720p';
    if (v >= 540) return '540p';
    if (v >= 480) return '480p';
    if (v >= 360) return '360p';
    return v + 'p';
  }

  /** Read quality from TikTok player / studio UI (user-selected tier) */
  function readQualityFromPage(v) {
    const root = v?.closest?.(
      '[class*="player"], [class*="Player"], [class*="video-card"], [class*="xgplayer"], [data-e2e*="video"]'
    ) || document;

    const scan = (el) => {
      if (!el || el.children?.length > 8) return null;
      const t = (el.textContent || '').trim();
      const a = (el.getAttribute?.('aria-label') || '').trim();
      for (const s of [t, a]) {
        if (!s || s.length > 32) continue;
        const m = s.match(/^(\d{3,4})\s*p$/i) || s.match(/\b(\d{3,4})p\b/i);
        if (m) return snapTierLabel(m[1]);
        if (/^auto$/i.test(s)) return 'Auto';
      }
      return null;
    };

    const active = root.querySelector(
      '[class*="quality" i][class*="active" i], [class*="quality" i][class*="selected" i], ' +
      '[class*="resolution" i][class*="active" i], [aria-checked="true"], [aria-selected="true"]'
    );
    const fromActive = active ? scan(active) : null;
    if (fromActive && fromActive !== 'Auto') return fromActive;

    const nodes = root.querySelectorAll(
      '[class*="quality" i], [class*="resolution" i], [class*="definition" i], ' +
      '[data-e2e*="quality" i], [aria-label*="quality" i], [aria-label*="resolution" i], button, span'
    );
    for (const el of nodes) {
      const q = scan(el);
      if (q && q !== 'Auto') return q;
    }
    return null;
  }

  function tierFromBitrate(br) {
    const n = Number(br);
    if (!n || n < 1) return null;
    const mbps = n > 10000 ? n / 1000000 : n / 1000;
    if (mbps >= 4.5) return '1080p';
    if (mbps >= 2.2) return '720p';
    if (mbps >= 1.2) return '540p';
    if (mbps >= 0.6) return '480p';
    return '360p';
  }

  function parseMediaUrl(url) {
    const out = { w: 0, h: 0, tier: null, bitrate: null };
    if (!url || url.startsWith('blob:')) return out;

    const s = String(url);
    const sl = s.toLowerCase();

    const wh = sl.match(/(\d{3,4})[x×](\d{3,4})/);
    if (wh) {
      out.w = parseInt(wh[1], 10);
      out.h = parseInt(wh[2], 10);
    }

    const params = [
      [/originwidth[=:](\d+)/i, 'w'],
      [/originheight[=:](\d+)/i, 'h'],
      [/origin_width[=:](\d+)/i, 'w'],
      [/origin_height[=:](\d+)/i, 'h'],
      [/[?&]width=(\d+)/i, 'w'],
      [/[?&]height=(\d+)/i, 'h'],
      [/video_width[=:](\d+)/i, 'w'],
      [/video_height[=:](\d+)/i, 'h'],
    ];
    for (const [re, key] of params) {
      const m = sl.match(re);
      if (m) out[key] = Math.max(out[key], parseInt(m[1], 10));
    }

    const def = sl.match(/definition[=:'"]*(\d{3,4})/i) ||
      sl.match(/[?&]vq=(\d)/i) ||
      sl.match(/gear[_-]?name[=:](\w+)/i);
    if (def) {
      const d = def[1];
      if (/^\d+$/.test(d)) {
        const n = parseInt(d, 10);
        if (n >= 1080) out.tier = '1080p';
        else if (n >= 720) out.tier = '720p';
        else if (n >= 540) out.tier = '540p';
        else out.tier = n + 'p';
      } else if (/1080|uhd|fhd|high|super|max|hd_1080/.test(d)) out.tier = '1080p';
      else if (/720|hd|medium|normal_720/.test(d)) out.tier = '720p';
      else if (/540/.test(d)) out.tier = '540p';
      else if (/480|low/.test(d)) out.tier = '480p';
    }

    if (/1080p|_1080_|\/1080\//.test(sl)) out.tier = out.tier || '1080p';
    else if (/720p|_720_|\/720\//.test(sl)) out.tier = out.tier || '720p';
    else if (/540p|_540_|\/540\//.test(sl)) out.tier = out.tier || '540p';
    else if (/480p|_480_/.test(sl)) out.tier = out.tier || '480p';
    else if (/360p|_360_/.test(sl)) out.tier = out.tier || '360p';

    if (/bytevc1|hevc|h265/.test(sl)) out.codec = 'HEVC';
    else if (/h264|avc/.test(sl)) out.codec = 'H.264';

    const br = sl.match(/[?&]br=(\d+)/i) || sl.match(/bitrate[=:](\d+)/i);
    if (br) {
      out.bitrate = br[1];
      out.tier = out.tier || tierFromBitrate(br[1]);
    }

    if (!out.tier && out.w && out.h) out.tier = tierFromDimensions(out.w, out.h);
    if (!out.tier && out.w && !out.h) out.tier = tierFromDimensions(out.w, Math.round(out.w * 16 / 9));
    if (!out.tier && out.h && !out.w) out.tier = tierFromDimensions(Math.round(out.h * 9 / 16), out.h);

    return out;
  }

  function urlMatchesDecode(p, vw, vh) {
    if (!p.w || !p.h || !vw || !vh) return false;
    const tol = 0.22;
    return Math.abs(p.w - vw) / vw <= tol && Math.abs(p.h - vh) / vh <= tol;
  }

  function collectActiveVideoUrls(v) {
    const urls = [];
    const add = (u) => {
      if (u && typeof u === 'string' && u.length > 8 && !u.startsWith('blob:')) urls.push(u);
    };
    add(v.currentSrc);
    add(v.src);
    v.querySelectorAll('source').forEach((s) => add(s.src));
    return urls;
  }

  function analyzeVideoMedia(v) {
    const vw = v.videoWidth || 0;
    const vh = v.videoHeight || 0;

    // 1) Decoded stream = what's actually playing
    let w = vw;
    let h = vh;
    let tier = (vw && vh) ? tierFromDimensions(vw, vh) : null;

    // 2) TikTok UI label (studio / player quality picker)
    const uiTier = readQualityFromPage(v);
    if (uiTier && uiTier !== 'Auto') tier = uiTier;

    // 3) Only use CDN URL if it matches decoded size (ignore preloaded 1080p ladder)
    let codec = null;
    for (const url of collectActiveVideoUrls(v)) {
      const p = parseMediaUrl(url);
      if (p.codec) codec = p.codec;
      if (!vw || !vh) {
        if (p.w) w = p.w;
        if (p.h) h = p.h;
        if (p.tier) tier = p.tier;
        continue;
      }
      if (!urlMatchesDecode(p, vw, vh)) continue;
      if (p.tier) tier = p.tier;
    }

    if (!tier && codec) tier = codec;

    return {
      videoResolution: w && h ? w + '×' + h : '—',
      qualityTier: tier || '—',
    };
  }

  function parseFpsFromSrc(src) {
    if (!src) return null;
    const m = String(src).match(/fps[=:_-]?(\d{2,3})/i) || String(src).match(/(\d{2,3})fps/i);
    return m ? Number(m[1]) : null;
  }

  function getBufferAhead(v) {
    if (!v?.buffered?.length) return 0;
    const t = v.currentTime;
    for (let i = 0; i < v.buffered.length; i++) {
      const start = v.buffered.start(i);
      const end = v.buffered.end(i);
      if (t >= start && t <= end) return Math.max(0, end - t);
    }
    return 0;
  }

  function getState(v) {
    if (!v) return 'No video';
    if (v.error) return 'Error';
    if (v.ended) return 'Ended';
    if (v.seeking) return 'Seeking';
    if (v.paused) return 'Paused';
    if (v.readyState < 2) return 'Loading';
    if (v.readyState < 3) return 'Buffering';
    return 'Playing';
  }

  function estimateFps(v) {
    for (const u of collectActiveVideoUrls(v)) {
      const f = parseFpsFromSrc(u);
      if (f && f >= 1 && f <= 240) return String(f);
    }
    if (fpsSamples.length >= 8) {
      const sorted = [...fpsSamples].sort((a,b) => a-b);
      // Faster stable intervals reduce undercount from skipped callbacks.
      const sample = sorted[Math.floor(sorted.length * 0.75)];
      const standard = [23.976,24,25,29.97,30,48,50,59.94,60,90,120,144,240];
      const nearest = standard.reduce((a,b) => Math.abs(b-sample)<Math.abs(a-sample)?b:a);
      cachedFps = '≈' + (Math.abs(nearest-sample)/nearest < 0.025 ? Math.round(nearest) : Math.round(sample));
    }
    return cachedFps;
  }
  function stopFpsTrack() {
    if (rvfHandle != null && trackedVideo?.cancelVideoFrameCallback) {
      try { trackedVideo.cancelVideoFrameCallback(rvfHandle); } catch (_) {}
    }
    rvfHandle = null;
    lastMediaTime = null;
    lastPresentedFrames = null;
  }
  function startFpsTrack(v) {
    const source = v.currentSrc || v.src || '';
    if (v !== trackedVideo || source !== trackedSource) {
      stopFpsTrack();
      trackedVideo = v;
      trackedSource = source;
      fpsSamples = [];
      cachedFps = '—';
    }
    if (!v?.requestVideoFrameCallback || rvfHandle != null) return;
    const onFrame = (_now, meta) => {
      rvfHandle = null;
      if (v !== trackedVideo) return;
      if (lastMediaTime != null && !v.seeking && !v.paused) {
        const dt = meta.mediaTime - lastMediaTime;
        const frames = meta.presentedFrames - lastPresentedFrames;
        if (dt > 0.001 && dt < 0.3 && frames > 0 && frames < 30) {
          const fps = frames / dt;
          if (fps >= 5 && fps <= 240) fpsSamples.push(fps);
          if (fpsSamples.length > 90) fpsSamples.shift();
        }
      }
      lastMediaTime = meta.mediaTime;
      lastPresentedFrames = meta.presentedFrames;
      rvfHandle = v.requestVideoFrameCallback(onFrame);
    };
    // Register even while paused: the callback will fire when playback starts.
    rvfHandle = v.requestVideoFrameCallback(onFrame);
  }

  function isUsableVideo(v) {
    if (!v?.isConnected) return false;
    if (v.videoWidth > 0 && v.videoHeight > 0) return true;
    const r = v.getBoundingClientRect();
    return r.width >= 16 && r.height >= 16;
  }

  function isInViewport(v) {
    const r = v.getBoundingClientRect();
    return r.bottom > 0 && r.top < window.innerHeight &&
      r.right > 0 && r.left < window.innerWidth;
  }

  function pickNewLock() {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    let best = null;
    let bestScore = -1;

    for (const v of document.querySelectorAll('video')) {
      if (!isUsableVideo(v) || !isInViewport(v)) continue;
      const r = v.getBoundingClientRect();
      const center = cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom;
      const visibleW = Math.max(0, Math.min(r.right,window.innerWidth)-Math.max(0,r.left));
      const visibleH = Math.max(0, Math.min(r.bottom,window.innerHeight)-Math.max(0,r.top));
      let score = visibleW * visibleH;
      if (center) score *= 3;
      if (!v.paused && !v.ended) score *= 1.2;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  }

  function resolveVideo() {
    const candidate = pickNewLock();
    lockedVideo = candidate;
    lockLostAt = 0;
    return candidate;
  }

  const fypUrls = new WeakMap();
  const pendingFyp = new Map();
  let nextResolveId = 0;
  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.type !== 'CB_RESOLVED_FYP') return;
    const pending = pendingFyp.get(event.data.token);
    if (!pending) return;
    pendingFyp.delete(event.data.token);
    if ((pending.video.currentSrc || pending.video.src || '') !== pending.source) return;
    try {
      const u = new URL(event.data.url);
      if (u.origin !== 'https://www.tiktok.com' || !/\/video\/\d{15,22}$/.test(u.pathname)) return;
      fypUrls.set(pending.video,{source:pending.source,url:u.origin+u.pathname,time:Date.now()});
      pushStats();
    } catch (_) {}
  });
  function getWatchingUrl(v) {
    const canonical = value => {
      try {
        const u = new URL(value,location.href);
        return /(^|\.)tiktok\.com$/.test(u.hostname) && /\/video\/\d+/.test(u.pathname)
          ? u.origin + u.pathname : '';
      } catch (_) { return ''; }
    };
    let node = v?.parentElement;
    for (let i=0; node && i<14; i++,node=node.parentElement) {
      for (const attribute of ['data-video-id','data-item-id','data-id']) {
        const id=node.getAttribute?.(attribute);
        if (/^\d{15,22}$/.test(id || '')) return 'https://www.tiktok.com/@_/video/'+id;
      }
      const links = [...node.querySelectorAll('a[href*="/video/"]')].map(a=>canonical(a.href)).filter(Boolean);
      const unique = [...new Set(links)];
      if (unique.length===1) return unique[0];
      if (unique.length>1) break;
    }
    const pageUrl=canonical(location.href);
    if(pageUrl)return pageUrl;
    if(v){
      const source=v.currentSrc || v.src || '';
      const cached=fypUrls.get(v);
      if(cached?.source===source && cached.url && Date.now()-cached.time<5000)return cached.url;
      if(!cached || cached.source!==source || Date.now()-cached.time>1000){
        fypUrls.set(v,{source,url:cached?.source===source ? cached.url : '',time:Date.now()});
        const token='cb-'+Date.now().toString(36)+'-'+(++nextResolveId);
        v.setAttribute('data-cb-resolve',token);
        pendingFyp.set(token,{video:v,source});
        for(const [key] of pendingFyp)if(pendingFyp.size>20)pendingFyp.delete(key);
        window.postMessage({type:'CB_RESOLVE_FYP',token},'*');
      }
      if(cached?.source===source && cached.url)return cached.url;
    }
    return '';
  }

  function buildStats(v) {
    const media = analyzeVideoMedia(v);
    const rect = v.getBoundingClientRect();
    const buf = getBufferAhead(v);
    const currentSec = v.currentTime || 0;
    const durationSec = isFinite(v.duration) ? v.duration : 0;

    return {
      watching: true,
      videoUrl: getWatchingUrl(v),
      mediaSource: v.currentSrc || v.src || '',
      videoResolution: media.videoResolution,
      screenResolution: Math.round(rect.width) + '×' + Math.round(rect.height),
      qualityTier: media.qualityTier,
      fps: estimateFps(v),
      time: formatTime(currentSec) + ' / ' + formatTime(durationSec),
      currentSec,
      durationSec,
      buffer: buf > 0 ? buf.toFixed(1) + 's' : '0s',
      state: getState(v),
      paused: !!v.paused,
    };
  }

  function emptyStats() {
    return {
      watching: false,
      videoUrl: getWatchingUrl(null),
      videoResolution: '—',
      screenResolution: '—',
      qualityTier: '—',
      fps: '—',
      time: '—',
      currentSec: 0,
      durationSec: 0,
      buffer: '—',
      state: 'No video',
      paused: false,
    };
  }

  function staticKey(stats) {
    return [
      stats.videoUrl,
      stats.mediaSource,
      stats.videoResolution,
      stats.screenResolution,
      stats.qualityTier,
      stats.fps,
      stats.state,
      stats.buffer,
    ].join('|');
  }

  function collectStats() {
    const v = resolveVideo();
    if (!v) {
      stopFpsTrack();
      trackedVideo = null;
      if (lastPushed && lockLostAt && Date.now() - lockLostAt < 4000) {
        return { ...lastPushed, watching: true, paused: true, state: lastPushed.state };
      }
      return emptyStats();
    }

    startFpsTrack(v);
    return buildStats(v);
  }

  function shouldPush(stats) {
    if (!stats.watching) {
      return !lastPushed || lastPushed.watching;
    }
    const sk = staticKey(stats);
    if (sk !== lastStaticKey) return true;
    if (!lastPushed) return true;
    if (stats.state !== lastPushed.state) return true;
    if (stats.paused !== lastPushed.paused) return true;
    if (!stats.paused) {
      const t = Math.floor(stats.currentSec || 0);
      const lastT = Math.floor(lastPushed.currentSec || 0);
      if (t !== lastT) return true;
    }
    return false;
  }

  function pushStats() {
    const stats = collectStats();
    if (!shouldPush(stats)) return;
    lastStaticKey = stats.watching ? staticKey(stats) : '';
    lastPushed = { ...stats };
    chrome.runtime.sendMessage({ type: 'VIDEO_STATS_UPDATE', stats }).catch(() => {});
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'CONTROL_VIDEO') {
      const video = resolveVideo();
      if (!video) { sendResponse({ ok: false }); return; }
      if (msg.action === 'seek' && Number.isFinite(msg.time) && Number.isFinite(video.duration)) {
        video.currentTime = Math.max(0, Math.min(video.duration, msg.time));
      } else if (msg.action === 'toggle') {
        if (video.paused) {
          video.play().then(() => sendResponse({ ok: true, stats: collectStats() }))
            .catch(() => sendResponse({ ok: false }));
          return true;
        }
        video.pause();
      }
      sendResponse({ ok: true, stats: collectStats() });
      return;
    }
    if (msg.type === 'GET_VIDEO_STATS') {
      const s = collectStats();
      sendResponse(s);
      return true;
    }
  });

  setInterval(pushStats, POLL_MS);
  window.addEventListener('scroll', pushStats, { passive: true, capture: true });
  document.addEventListener('seeking', e => {
    if (e.target === trackedVideo) { lastMediaTime = null; lastPresentedFrames = null; }
  }, true);

  document.addEventListener('pause', (e) => {
    if (e.target === lockedVideo) pushStats();
  }, true);
  document.addEventListener('play', (e) => {
    if (e.target === lockedVideo) pushStats();
  }, true);

  document.addEventListener('loadedmetadata', (e) => {
    if (e.target instanceof HTMLVideoElement && e.target === lockedVideo) pushStats();
  }, true);
  document.addEventListener('resize', () => {
    if (lockedVideo) pushStats();
  });

  pushStats();
})();
